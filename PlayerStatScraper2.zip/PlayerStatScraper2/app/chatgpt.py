import requests
import os

API_KEY = os.getenv("DEEPSEEK_API_KEY")  # Place-la dans ton .env

def summarize_stats(player_name, df):
    prompt = f"Fais un résumé des performances de {player_name} cette saison :\n{df.to_string(index=False)}"
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    payload = {
        "model": "deepseek-chat",
        "messages": [{"role": "user", "content": prompt}]
    }
    response = requests.post("https://api.deepseek.com/v1/chat/completions", json=payload, headers=headers)
    return response.json()['choices'][0]['message']['content']