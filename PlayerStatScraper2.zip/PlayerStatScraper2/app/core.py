import pandas as pd
from main import scrape_player_stats  # adapte ça selon ton script existant
from rapidfuzz import process

def get_player_stats(player_name: str):
    df = scrape_player_stats(player_name)
    df['Player'] = player_name
    return df

def search_player(query, player_list):
    result, score, _ = process.extractOne(query, player_list)
    return result