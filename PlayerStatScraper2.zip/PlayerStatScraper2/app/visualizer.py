import plotly.express as px

def plot_stats_bar(df, stats_to_plot):
    df_plot = df[stats_to_plot].T.reset_index()
    df_plot.columns = ['Metric', 'Value']
    fig = px.bar(df_plot, x='Metric', y='Value', color='Metric')
    return fig