import streamlit as st
import pandas as pd
from app.core import get_player_stats, search_player
from app.visualizer import plot_stats_bar
from app.chatgpt import summarize_stats

# Charger base de joueurs
players_df = pd.read_csv("app/players.csv")
player_names = players_df['name'].tolist()
player_ids = players_df['id'].tolist()

st.title("⚽ Analyse de Joueur")

query = st.text_input("🔍 Entrez un nom de joueur")
if query:
    matched = search_player(query, player_names)
    player_id = players_df[players_df.name == matched]["id"].values[0]

    st.success(f"Joueur sélectionné : {matched}")
    df_stats = get_player_stats(player_id)

    st.subheader("📊 Statistiques")
    st.dataframe(df_stats)

    st.plotly_chart(plot_stats_bar(df_stats, ['goals', 'assists', 'minutes_played']))

    if st.button("🔎 Analyse par IA"):
        with st.spinner("Génération du résumé..."):
            result = summarize_stats(matched, df_stats)
        st.markdown(result)